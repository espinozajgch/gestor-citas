<script src="../../vendor/plugin/jquery/jquery.min.js"></script>
<script src="../../vendor/plugin/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../vendor/plugin/jquery-ui/jquery-ui.js"></script>
<script src="../../vendor/plugin/jquery-ui-custom/jquery-ui.min.js"></script>

<!--script src="vendor/plugin/html5imageupload/html5imageupload.js"></script-->