<!--link rel="icon" href="../img/desing/favicon.ico"-->
<!-- Bootstrap core CSS -->
<link href="../../vendor/plugin/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="../../vendor/plugin/jquery-ui/jquery-ui.css" rel="stylesheet">
<link href="../../vendor/plugin/jquery-ui-custom/jquery-ui.min.css" rel="stylesheet">
<link href="../../vendor/plugin/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>

<!--link href="vendor/plugin/html5imageupload/demo.html5imageupload.css" rel="stylesheet"--> 

<!-- Custom styles for this template -->
<link href="css/modern-business.css" rel="stylesheet">
<link href="css/estilos.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../../css/preloader.css">